# starter-express-api

This is the simplest possible nodejs api using express that responds to any request with: 
```
Yo!
```

### Deploy it in 7 seconds: 

[![Deploy to Cyclic](https://deploy.cyclic.app/button.svg)](https://deploy.cyclic.app/)

